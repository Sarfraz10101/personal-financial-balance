import React from 'react';

const Header = () => {
  return (
    <h2>
      Personal Finance Tracker
    </h2>
  );
}

export default Header;
